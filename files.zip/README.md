# GroupMe Bot — Secure Linux Command Interface

A production-ready GroupMe bot that runs on Ubuntu Server 22.04 LTS (tested on
Le Potato SBC). It listens for commands via GroupMe webhook and executes a
strict whitelist of read-only Linux system commands, returning the output to
the chat.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Security Design](#security-design)
3. [Project Structure](#project-structure)
4. [Prerequisites](#prerequisites)
5. [Step-by-Step Deployment](#step-by-step-deployment)
   - [Part 1: Server Setup](#part-1-server-setup)
   - [Part 2: GroupMe Bot Registration](#part-2-groupme-bot-registration)
   - [Part 3: Project Installation](#part-3-project-installation)
   - [Part 4: Public Tunnel Setup](#part-4-public-tunnel-setup)
   - [Part 5: Register Webhook with GroupMe](#part-5-register-webhook-with-groupme)
   - [Part 6: Start and Verify the Service](#part-6-start-and-verify-the-service)
6. [Available Commands](#available-commands)
7. [Rate Limiting](#rate-limiting)
8. [Configuration Reference](#configuration-reference)
9. [Monitoring & Logs](#monitoring--logs)
10. [Cloudflare Tunnel Setup (Recommended)](#cloudflare-tunnel-setup-recommended)
11. [ngrok Setup (Quick Testing)](#ngrok-setup-quick-testing)
12. [Troubleshooting](#troubleshooting)
13. [Updating the Bot](#updating-the-bot)

---

## Architecture Overview

```
GroupMe Group Chat
       │  (user sends "!disk")
       ▼
GroupMe Servers
       │  (POST /webhook?token=SECRET)
       ▼
Cloudflare Tunnel  ──────────────►  Le Potato (127.0.0.1:5000)
(or ngrok)                                │
                                          │  Flask + gunicorn
                                          │  ↓
                                    Whitelist lookup
                                          │
                                    subprocess.run(shell=False)
                                          │
                                    Trim output (≤900 chars)
                                          │
                                    POST to GroupMe Bot API
                                          │
                                          ▼
                                  GroupMe Group Chat
                                  (bot posts result)
```

Key design decision: The Flask app binds to **127.0.0.1:5000 only**. The
public-facing HTTPS connection is handled entirely by the tunnel process. This
means UFW never needs to open port 5000 to the internet.

---

## Security Design

| Threat | Mitigation |
|--------|-----------|
| Command injection | `shell=False` — no shell is ever invoked |
| Arbitrary command execution | Hard-coded whitelist dict — user input never becomes part of argv |
| Bot feedback loops | `sender_type == "bot"` check discards all bot messages |
| Webhook spoofing | Optional `WEBHOOK_TOKEN` — must be present in query string |
| Brute-force / flooding | 3s cooldown + 10 commands/60s rolling cap |
| Running as root | Dedicated `gmbot` system user with `--shell /bin/false` |
| Sensitive env vars in logs | `__env__` handler only exposes a safe allowlist of env keys |
| Port exposure | Bot binds loopback only; only tunnel process is public |
| Filesystem writes | `ProtectSystem=strict` in systemd; `ReadWritePaths` only for logs |
| Privilege escalation | `NoNewPrivileges=true` + empty `CapabilityBoundingSet` |
| Output pollution | All output trimmed to 900 chars before sending |

---

## Project Structure

```
groupme-bot/
├── .env.example              ← Copy to .env, fill in secrets
├── .gitignore                ← Excludes .env, venv, logs, __pycache__
├── requirements.txt          ← Python dependencies
├── README.md                 ← This file
│
├── app/
│   ├── __init__.py           ← Package marker
│   ├── main.py               ← Flask app & webhook endpoint
│   ├── commands.py           ← Whitelist, command execution, output trimming
│   ├── rate_limiter.py       ← Cooldown & per-minute cap
│   ├── messenger.py          ← GroupMe Bot API client (with retry)
│   └── logger.py             ← Rotating file + console logging
│
├── logs/
│   └── .gitkeep              ← Keeps directory in git; actual logs are ignored
│
├── systemd/
│   └── groupme-bot.service   ← Systemd unit file
│
└── scripts/
    └── setup.sh              ← Automated setup script
```

---

## Prerequisites

On your Le Potato / Ubuntu 22.04 server:

- Ubuntu Server 22.04 LTS (minimal install is fine)
- Python 3.10+ (installed by default on 22.04)
- sudo/root access for initial setup
- Outbound internet access (the server calls GroupMe API)
- A GroupMe account and an existing group to add the bot to

---

## Step-by-Step Deployment

### Part 1: Server Setup

SSH into your Le Potato:

```bash
ssh youruser@<le-potato-ip>
```

Update the system:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git python3-venv python3-pip curl ufw
```

Set up SSH key auth (if not already done) and disable password auth for security:

```bash
# On your LOCAL machine, copy your public key:
ssh-copy-id youruser@<le-potato-ip>

# Then on the server, disable password auth:
sudo nano /etc/ssh/sshd_config
# Set: PasswordAuthentication no
sudo systemctl restart ssh
```

### Part 2: GroupMe Bot Registration

1. Open https://dev.groupme.com/bots in your browser.
2. Click **Create Bot**.
3. Fill in:
   - **Name**: anything (shown as sender name in the group)
   - **Group**: the group you want the bot in
   - **Callback URL**: leave BLANK for now (we'll fill this after tunnel setup)
   - **Avatar URL**: optional image URL
4. Click **Submit**.
5. **Copy the Bot ID** — you'll need this for your `.env` file.

### Part 3: Project Installation

Clone the repository onto your server:

```bash
cd /tmp
git clone https://github.com/yourname/groupme-bot.git
cd groupme-bot
```

Create your environment file:

```bash
cp .env.example .env
nano .env
```

Fill in the values:

```ini
BOT_ID=your_actual_bot_id_from_groupme
WEBHOOK_TOKEN=pick_any_long_random_string_here
PORT=5000
FLASK_DEBUG=false
```

Generate a strong random token if you want:

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

Run the automated setup script:

```bash
sudo bash scripts/setup.sh
```

This will:
- Install system packages
- Create the `gmbot` user
- Copy files to `/opt/groupme-bot`
- Create a Python virtual environment
- Install Python dependencies
- Configure UFW
- Install and enable the systemd service

**Or, do it manually** — see below for each step.

#### Manual Installation (alternative to setup.sh)

```bash
# Create system user
sudo useradd --system --no-create-home --shell /bin/false gmbot

# Create install directory
sudo mkdir -p /opt/groupme-bot/{app,logs,systemd}

# Copy files
sudo cp -r app/ /opt/groupme-bot/app/
sudo cp requirements.txt /opt/groupme-bot/
sudo cp .env /opt/groupme-bot/.env
sudo chmod 600 /opt/groupme-bot/.env

# Create virtual environment
sudo python3 -m venv /opt/groupme-bot/venv
sudo /opt/groupme-bot/venv/bin/pip install -r /opt/groupme-bot/requirements.txt

# Set ownership
sudo chown -R gmbot:gmbot /opt/groupme-bot
sudo chmod 770 /opt/groupme-bot/logs

# Install service
sudo cp systemd/groupme-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable groupme-bot
```

### Part 4: Public Tunnel Setup

The bot listens on `127.0.0.1:5000` (loopback only). GroupMe needs to reach it
over HTTPS from the internet. You have two options:

#### Option A: Cloudflare Tunnel (Recommended — permanent, free, no port forwarding)

See the full [Cloudflare Tunnel Setup](#cloudflare-tunnel-setup-recommended) section below.

#### Option B: ngrok (Good for testing)

See the [ngrok Setup](#ngrok-setup-quick-testing) section below.

### Part 5: Register Webhook with GroupMe

Once your tunnel is running and you have an HTTPS URL:

1. Go to https://dev.groupme.com/bots
2. Click **Edit** on your bot
3. Set **Callback URL** to:
   ```
   https://your-tunnel-domain.com/webhook?token=YOUR_WEBHOOK_TOKEN
   ```
   Replace `your-tunnel-domain.com` with your actual Cloudflare or ngrok URL,
   and `YOUR_WEBHOOK_TOKEN` with the value you set in `.env`.
4. Click **Update**.

### Part 6: Start and Verify the Service

```bash
# Start the bot
sudo systemctl start groupme-bot

# Check status
sudo systemctl status groupme-bot

# Follow live logs
sudo journalctl -u groupme-bot -f
```

You should see output like:
```
groupme-bot[1234]: [2024-01-15 10:30:00] INFO gunicorn.error Starting gunicorn 22.0.0
groupme-bot[1234]: [2024-01-15 10:30:00] INFO gunicorn.error Listening at: http://127.0.0.1:5000
```

Test the health endpoint:
```bash
curl http://127.0.0.1:5000/health
# Expected: {"service":"groupme-bot","status":"healthy"}
```

Send `!help` in your GroupMe group — the bot should respond with the command list.

---

## Available Commands

| Command | Description |
|---------|-------------|
| **System** | |
| `!uptime` | System uptime |
| `!whoami` | Current user |
| `!hostname` | Server hostname |
| `!ip` | All IP addresses |
| `!kernel` | Kernel version |
| `!date` | Current date/time |
| `!arch` | CPU architecture |
| `!os` | OS release info |
| `!loadavg` | 1/5/15-min load averages |
| **Disk** | |
| `!disk` | Disk usage (all mounts) |
| `!disk_root` | Root partition usage |
| `!lsblk` | Block device list |
| `!inode` | Inode usage |
| **Memory** | |
| `!memory` | RAM & swap usage |
| `!memory_raw` | Memory in bytes |
| **CPU & Processes** | |
| `!cpu` | CPU usage from top |
| `!processes` | Top 5 processes by memory |
| `!pstree` | Process tree |
| **Network** | |
| `!ifconfig` | Network interfaces (ip addr) |
| `!route` | Routing table |
| `!netstat` | Listening ports (ss -tuln) |
| `!ping_gw` | Ping default gateway |
| `!arp` | ARP table |
| `!dns` | DNS resolver config |
| `!hosts` | /etc/hosts contents |
| `!nslookup` | DNS lookup for google.com |
| **Services** | |
| `!services` | Running systemd services |
| `!failed` | Failed systemd units |
| `!timers` | Active systemd timers |
| **Logs** | |
| `!syslog` | Last 10 syslog lines |
| `!auth_log` | Last 10 auth.log lines |
| `!dmesg` | Last 10 kernel messages |
| **Hardware/SBC** | |
| `!temperature` | CPU temperature (vcgencmd or sysfs) |
| `!voltage` | Core voltage (vcgencmd) |
| **Files** | |
| `!ls` | List /home |
| `!ls_tmp` | List /tmp |
| `!ls_var` | List /var/log |
| **Users** | |
| `!users` | Logged-in users |
| `!last` | Last 5 logins |
| `!groups` | Current user's groups |
| `!id` | Current UID/GID |
| **Packages** | |
| `!pkg_count` | Number of installed packages |
| `!apt_upgrades` | Available package upgrades |
| **Git** | |
| `!git_status` | Bot repo git status |
| `!git_log` | Last 5 bot commits |
| **Misc** | |
| `!env` | Safe env var subset |
| `!timezone` | Server timezone |
| `!locale` | Locale settings |
| `!help` | This list (in GroupMe) |

---

## Rate Limiting

Two independent limits are enforced:

| Limit | Value | Scope |
|-------|-------|-------|
| Cooldown | 3 seconds minimum between commands | Global |
| Per-minute cap | 10 commands per 60-second window | Global |

When a limit is hit, the bot posts a friendly message explaining the wait time.
These limits are defined as constants at the top of `app/rate_limiter.py` and
can be adjusted.

---

## Configuration Reference

All configuration is in `/opt/groupme-bot/.env`:

| Variable | Required | Description |
|----------|----------|-------------|
| `BOT_ID` | **Yes** | GroupMe Bot ID from dev.groupme.com/bots |
| `WEBHOOK_TOKEN` | Recommended | Secret appended to webhook URL as `?token=` |
| `PORT` | No (default: 5000) | Port for gunicorn to listen on |
| `FLASK_DEBUG` | No (default: false) | Enable Flask debug mode (dev only!) |

To update a config value:
```bash
sudo nano /opt/groupme-bot/.env
sudo systemctl restart groupme-bot
```

---

## Monitoring & Logs

### Real-time logs via journald

```bash
# Follow live
sudo journalctl -u groupme-bot -f

# Last 100 lines
sudo journalctl -u groupme-bot -n 100

# Since last boot
sudo journalctl -u groupme-bot -b

# Since a specific time
sudo journalctl -u groupme-bot --since "2024-01-15 10:00:00"
```

### Rotating log file

The app also writes to `/opt/groupme-bot/logs/groupme_bot.log` (rotates at 5MB,
keeps 3 backups):

```bash
# Follow
sudo tail -f /opt/groupme-bot/logs/groupme_bot.log

# Search for errors
sudo grep "ERROR" /opt/groupme-bot/logs/groupme_bot.log

# Search for a specific command
sudo grep "!disk" /opt/groupme-bot/logs/groupme_bot.log
```

### Service status

```bash
sudo systemctl status groupme-bot
```

---

## Cloudflare Tunnel Setup (Recommended)

Cloudflare Tunnel is free, creates a permanent subdomain under
`trycloudflare.com` (or your own domain), handles HTTPS termination, and
requires **zero port forwarding** on your router.

### Install cloudflared

```bash
# Download the ARM64 binary (for Le Potato / AArch64)
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 \
    -o /usr/local/bin/cloudflared
chmod +x /usr/local/bin/cloudflared
cloudflared --version
```

> If your Le Potato runs 32-bit ARM (armv7), replace `arm64` with `arm`.
> Check with: `uname -m`

### Quick test (no account needed)

```bash
# Start bot first, then in another terminal:
cloudflared tunnel --url http://localhost:5000
```

This gives you a temporary URL like `https://random-words.trycloudflare.com`.
**This URL changes every time** — use the persistent method below for production.

### Persistent tunnel (free Cloudflare account required)

```bash
# 1. Log in to Cloudflare (opens browser — may need to do this on another machine
#    if Le Potato has no display)
cloudflared tunnel login

# If headless, copy the URL from the output and open it on another device.
# The cert file is saved to ~/.cloudflared/cert.pem

# 2. Create a named tunnel
cloudflared tunnel create groupme-bot

# Note the Tunnel ID (UUID) printed — you'll need it below

# 3. Create tunnel config file
mkdir -p ~/.cloudflared
cat > ~/.cloudflared/config.yml << 'EOF'
tunnel: YOUR_TUNNEL_ID_HERE
credentials-file: /home/youruser/.cloudflared/YOUR_TUNNEL_ID_HERE.json

ingress:
  - hostname: bot.yourdomain.com   # or use a trycloudflare subdomain
    service: http://localhost:5000
  - service: http_status:404
EOF

# 4. Route DNS (if using your own domain)
cloudflared tunnel route dns groupme-bot bot.yourdomain.com

# 5. Install cloudflared as a systemd service
sudo cloudflared service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
sudo systemctl status cloudflared
```

Your webhook URL will be: `https://bot.yourdomain.com/webhook?token=YOUR_TOKEN`

---

## ngrok Setup (Quick Testing)

```bash
# Download ngrok for ARM64
curl -L https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz | tar xz
sudo mv ngrok /usr/local/bin/

# Authenticate (free account at ngrok.com)
ngrok config add-authtoken YOUR_NGROK_TOKEN

# Start tunnel (while bot is running)
ngrok http 5000
```

The output shows your public URL, e.g.:
```
Forwarding  https://abc123.ngrok.io -> http://localhost:5000
```

Use `https://abc123.ngrok.io/webhook?token=YOUR_TOKEN` as the GroupMe callback URL.

**Note**: Free ngrok URLs change every restart. Use Cloudflare Tunnel for a
persistent URL without a paid ngrok subscription.

### ngrok as a systemd service (optional)

```bash
sudo tee /etc/systemd/system/ngrok.service << 'EOF'
[Unit]
Description=ngrok HTTP tunnel
After=network-online.target groupme-bot.service
Wants=network-online.target

[Service]
User=gmbot
ExecStart=/usr/local/bin/ngrok http 5000 --log stdout
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable ngrok
sudo systemctl start ngrok
```

---

## Troubleshooting

### Bot doesn't respond to messages

1. **Check the service is running:**
   ```bash
   sudo systemctl status groupme-bot
   ```

2. **Check the tunnel is running:**
   ```bash
   sudo systemctl status cloudflared   # or ngrok
   ```

3. **Verify the webhook URL is registered correctly:**
   - Go to https://dev.groupme.com/bots
   - The Callback URL should be your tunnel URL + `/webhook?token=YOUR_TOKEN`

4. **Test the endpoint manually:**
   ```bash
   curl -X POST http://127.0.0.1:5000/webhook \
     -H "Content-Type: application/json" \
     -d '{"text":"!uptime","sender_type":"user","name":"TestUser","sender_id":"123"}'
   ```
   You should see `{"status":"ok"}` and the bot should post to the group.

5. **Check logs for errors:**
   ```bash
   sudo journalctl -u groupme-bot -n 50 --no-pager
   ```

### Service fails to start

```bash
sudo journalctl -u groupme-bot -b --no-pager
```

Common causes:
- `.env` file missing or has wrong permissions
- `BOT_ID` not set in `.env`
- Port 5000 already in use: `sudo lsof -i :5000`
- Virtual environment not created: re-run `setup.sh` or install manually

### Bot posts "Rate limited" constantly

The 3-second cooldown and 10/minute cap are global. If the group is very active,
adjust the constants in `app/rate_limiter.py`:

```python
COOLDOWN_SECONDS: float = 1.0      # Reduce cooldown
MAX_COMMANDS_PER_MINUTE: int = 20  # Increase cap
```

Then restart: `sudo systemctl restart groupme-bot`

### "Command not found" errors for system tools

Some commands (e.g., `vcgencmd`) may not be installed. The bot handles missing
binaries gracefully and reports "Command not found" in the GroupMe chat.

To install missing tools:
```bash
sudo apt install -y <package-name>
```

### Permission denied on log files

```bash
sudo chown -R gmbot:gmbot /opt/groupme-bot/logs
sudo chmod 770 /opt/groupme-bot/logs
```

### Updating BOT_ID or WEBHOOK_TOKEN

```bash
sudo nano /opt/groupme-bot/.env
sudo systemctl restart groupme-bot
```

---

## Updating the Bot

```bash
# On your dev machine, pull latest changes, then:
cd /tmp/groupme-bot
git pull

# Copy updated app files
sudo cp -r app/ /opt/groupme-bot/app/
sudo chown -R gmbot:gmbot /opt/groupme-bot/app/

# If requirements.txt changed:
sudo /opt/groupme-bot/venv/bin/pip install -r requirements.txt

# Restart
sudo systemctl restart groupme-bot
sudo systemctl status groupme-bot
```

---

## Adding New Commands

Edit `app/commands.py` and add an entry to the `COMMANDS` dict:

```python
# Simple case — direct argv list
"!mycommand": ["/usr/bin/some-binary", "--flag", "arg"],

# Complex case — add a handler function and a sentinel
"!mycommand": "__mycommand__",
```

For complex commands, add a handler function:
```python
def _handle_mycommand() -> str:
    raw = _run(["/usr/bin/tool", "--flag"])
    # post-process raw output
    return raw.upper()
```

And register it in `_SPECIAL_DISPATCH`:
```python
"__mycommand__": _handle_mycommand,
```

Then restart: `sudo systemctl restart groupme-bot`

**Security rules for new commands:**
- Never add `rm`, `dd`, `mkfs`, `chmod`, `chown`, `sudo`, `su`, or any command that modifies the system
- Never use shell metacharacters in argv lists
- Never build argv from user-supplied strings
- If the command needs pipeline-style output, post-process in Python
