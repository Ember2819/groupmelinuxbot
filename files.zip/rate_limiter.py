"""
rate_limiter.py — Thread-safe cooldown and per-minute cap enforcement.

Two independent guards are enforced:

1. **Global cooldown** — At least COOLDOWN_SECONDS must elapse between any
   two command executions, regardless of who sent the command.  This prevents
   a single fast-typing user (or a bot loop) from hammering the server.

2. **Per-minute cap** — No more than MAX_COMMANDS_PER_MINUTE commands may
   execute in any rolling 60-second window.  Older timestamps are purged from
   the deque on each check so memory use stays constant.

Both checks are protected by a threading.Lock so the Flask development server
(which is single-threaded, but a production WSGI server may not be) can't race
between the read and write of shared state.
"""

import threading
import time
from collections import deque

from app.logger import get_logger

logger = get_logger(__name__)

# ------------------------------------------------------------------
# Tuneable constants (edit here or override via environment variables
# in a future iteration).
# ------------------------------------------------------------------
COOLDOWN_SECONDS: float = 3.0       # Minimum gap between any two commands
MAX_COMMANDS_PER_MINUTE: int = 10   # Rolling-window cap


class RateLimiter:
    """
    Enforce a per-bot-instance cooldown and a rolling per-minute cap.

    This is intentionally *global* (not per-user) because the bot runs on a
    resource-constrained single-board computer.  A per-user limiter would
    require tracking an unbounded number of users and is overkill for a small
    private GroupMe group.
    """

    def __init__(
        self,
        cooldown: float = COOLDOWN_SECONDS,
        max_per_minute: int = MAX_COMMANDS_PER_MINUTE,
    ) -> None:
        self._cooldown = cooldown
        self._max_per_minute = max_per_minute

        self._last_execution: float = 0.0          # epoch seconds
        self._minute_window: deque[float] = deque()  # timestamps of recent cmds
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_allowed(self) -> tuple[bool, str]:
        """
        Check whether a new command may execute RIGHT NOW.

        Returns:
            (True, "")                    — command is allowed
            (False, human-readable reason) — command is rate-limited
        """
        now = time.monotonic()

        with self._lock:
            # 1. Cooldown check
            elapsed = now - self._last_execution
            if elapsed < self._cooldown:
                wait = self._cooldown - elapsed
                reason = f"Cooldown active — please wait {wait:.1f}s"
                logger.debug("Rate limit: cooldown. elapsed=%.2fs", elapsed)
                return False, reason

            # 2. Per-minute cap — purge timestamps older than 60 seconds
            cutoff = now - 60.0
            while self._minute_window and self._minute_window[0] < cutoff:
                self._minute_window.popleft()

            if len(self._minute_window) >= self._max_per_minute:
                oldest = self._minute_window[0]
                reset_in = 60.0 - (now - oldest)
                reason = (
                    f"Rate limit reached ({self._max_per_minute}/min). "
                    f"Resets in {reset_in:.0f}s"
                )
                logger.debug(
                    "Rate limit: per-minute cap. window_size=%d",
                    len(self._minute_window),
                )
                return False, reason

            # All checks passed — record this execution
            self._last_execution = now
            self._minute_window.append(now)
            return True, ""

    def reset(self) -> None:
        """Reset all rate-limit state.  Useful for testing."""
        with self._lock:
            self._last_execution = 0.0
            self._minute_window.clear()
