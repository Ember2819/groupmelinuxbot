"""
logger.py — Structured logging configuration for the GroupMe bot.

Uses Python's built-in logging module with a rotating file handler so logs
don't grow unbounded on a constrained SBC like Le Potato. All modules
import `get_logger()` rather than calling logging.getLogger() directly,
which ensures consistent formatting across the entire application.
"""

import logging
import os
from logging.handlers import RotatingFileHandler

# ------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
LOG_FILE = os.path.join(LOG_DIR, "groupme_bot.log")

# 5 MB per file, keep 3 rotated backups → max ~15 MB total on disk
MAX_BYTES = 5 * 1024 * 1024
BACKUP_COUNT = 3

# Format includes timestamp, level, module name, and message.
# This makes grepping logs by module trivial.
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _ensure_log_dir() -> None:
    """Create the logs directory if it doesn't already exist."""
    os.makedirs(LOG_DIR, exist_ok=True)


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger that writes to both the console and a rotating
    log file.  Calling this multiple times with the same *name* is safe —
    Python's logging module returns the same Logger object on subsequent
    calls, so handlers are only attached once.

    Args:
        name: Typically the module's ``__name__`` attribute.

    Returns:
        A configured :class:`logging.Logger` instance.
    """
    _ensure_log_dir()

    logger = logging.getLogger(name)

    # Only configure once, even if this function is called multiple times.
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    # --- Console handler (INFO and above) ---
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    # --- Rotating file handler (DEBUG and above) ---
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=MAX_BYTES,
        backupCount=BACKUP_COUNT,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger
