#!/usr/bin/env bash
# =============================================================================
# setup.sh — Full automated setup for GroupMe Bot on Ubuntu 22.04 LTS
#
# Run as root (sudo bash setup.sh) OR run each section manually.
#
# What this script does:
#   1. Creates the 'gmbot' system user
#   2. Installs system dependencies
#   3. Copies project files to /opt/groupme-bot
#   4. Creates and populates the Python virtual environment
#   5. Configures UFW firewall rules
#   6. Installs and enables the systemd service
#   7. Prints next-step instructions
#
# Usage:
#   sudo bash scripts/setup.sh
#
# The script is idempotent — safe to run more than once.
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colours for readability
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# Safety checks
# ---------------------------------------------------------------------------
[[ $EUID -ne 0 ]] && error "Please run as root:  sudo bash scripts/setup.sh"
[[ ! -f "requirements.txt" ]] && error "Run this from the project root (where requirements.txt lives)."

PROJECT_SRC="$(pwd)"
INSTALL_DIR="/opt/groupme-bot"
BOT_USER="gmbot"
SERVICE_FILE="systemd/groupme-bot.service"
VENV_DIR="${INSTALL_DIR}/venv"

# ---------------------------------------------------------------------------
# 1. System update & dependencies
# ---------------------------------------------------------------------------
info "Updating package lists…"
apt-get update -qq

info "Installing system packages…"
apt-get install -y -qq \
    python3 \
    python3-venv \
    python3-pip \
    git \
    curl \
    ufw \
    net-tools \
    procps \
    iputils-ping \
    dnsutils \
    sysstat \
    lsb-release

success "System packages installed."

# ---------------------------------------------------------------------------
# 2. Create dedicated system user
# ---------------------------------------------------------------------------
if id "${BOT_USER}" &>/dev/null; then
    warn "User '${BOT_USER}' already exists — skipping creation."
else
    info "Creating system user '${BOT_USER}'…"
    # --system      : No password, no login shell, UID < 1000
    # --no-create-home: We'll use /opt/groupme-bot as the home equivalent
    # --shell /bin/false: Prevents interactive login
    useradd \
        --system \
        --no-create-home \
        --shell /bin/false \
        --comment "GroupMe Bot service account" \
        "${BOT_USER}"
    success "User '${BOT_USER}' created."
fi

# ---------------------------------------------------------------------------
# 3. Create installation directory and copy files
# ---------------------------------------------------------------------------
info "Creating installation directory at ${INSTALL_DIR}…"
mkdir -p "${INSTALL_DIR}"/{app,logs,systemd}

info "Copying project files…"
cp -r app/     "${INSTALL_DIR}/app/"
cp -r systemd/ "${INSTALL_DIR}/systemd/"
cp requirements.txt "${INSTALL_DIR}/"

# Copy .env if it exists; otherwise copy the example
if [[ -f ".env" ]]; then
    info "Copying .env to ${INSTALL_DIR}/.env"
    cp .env "${INSTALL_DIR}/.env"
    chmod 600 "${INSTALL_DIR}/.env"
    warn "Review ${INSTALL_DIR}/.env and ensure BOT_ID and WEBHOOK_TOKEN are set."
else
    cp .env.example "${INSTALL_DIR}/.env"
    chmod 600 "${INSTALL_DIR}/.env"
    warn "No .env found — copied .env.example to ${INSTALL_DIR}/.env"
    warn "EDIT ${INSTALL_DIR}/.env and set BOT_ID and WEBHOOK_TOKEN before starting!"
fi

# Touch gitkeep so the logs dir is tracked by git
touch "${INSTALL_DIR}/logs/.gitkeep"

success "Project files copied."

# ---------------------------------------------------------------------------
# 4. Python virtual environment
# ---------------------------------------------------------------------------
info "Creating Python virtual environment at ${VENV_DIR}…"
python3 -m venv "${VENV_DIR}"

info "Installing Python dependencies…"
"${VENV_DIR}/bin/pip" install --upgrade pip -q
"${VENV_DIR}/bin/pip" install -r "${INSTALL_DIR}/requirements.txt" -q

success "Python environment ready."

# ---------------------------------------------------------------------------
# 5. File ownership & permissions
# ---------------------------------------------------------------------------
info "Setting file ownership to ${BOT_USER}:${BOT_USER}…"
chown -R "${BOT_USER}:${BOT_USER}" "${INSTALL_DIR}"

# Logs dir needs write access; everything else can be read-only for the user
chmod -R 750 "${INSTALL_DIR}"
chmod 770 "${INSTALL_DIR}/logs"
chmod 600 "${INSTALL_DIR}/.env"

success "Permissions configured."

# ---------------------------------------------------------------------------
# 6. UFW firewall
# ---------------------------------------------------------------------------
info "Configuring UFW firewall…"

# Enable UFW if not already active (with --force to skip the "disruptive?" prompt)
ufw --force enable

# SSH — keep this open or you'll lock yourself out!
ufw allow OpenSSH

# We do NOT open port 5000 to the internet.
# The bot listens on 127.0.0.1:5000 (loopback only).
# Cloudflare Tunnel / ngrok handles the public-facing connection —
# they connect outbound from the server, so no inbound port is needed.
info "Port 5000 is intentionally NOT opened in UFW."
info "Use Cloudflare Tunnel or ngrok to expose the webhook endpoint."

ufw status verbose
success "UFW configured."

# ---------------------------------------------------------------------------
# 7. Systemd service
# ---------------------------------------------------------------------------
info "Installing systemd service…"
cp "${SERVICE_FILE}" /etc/systemd/system/groupme-bot.service

systemctl daemon-reload
systemctl enable groupme-bot

success "Service enabled (will start on next boot)."

# ---------------------------------------------------------------------------
# Done — print next steps
# ---------------------------------------------------------------------------
echo ""
echo -e "${GREEN}================================================================${NC}"
echo -e "${GREEN}  Setup complete!${NC}"
echo -e "${GREEN}================================================================${NC}"
echo ""
echo -e "${YELLOW}NEXT STEPS:${NC}"
echo ""
echo "  1. Edit your environment file:"
echo "     sudo nano ${INSTALL_DIR}/.env"
echo "     → Set BOT_ID (from https://dev.groupme.com/bots)"
echo "     → Set WEBHOOK_TOKEN (any random secret string)"
echo ""
echo "  2. Set up a public tunnel (choose one):"
echo ""
echo "     Option A — Cloudflare Tunnel (RECOMMENDED, free, persistent):"
echo "       See: README.md → Cloudflare Tunnel Setup"
echo ""
echo "     Option B — ngrok (quick testing):"
echo "       ngrok http 5000"
echo "       Copy the https://xxxx.ngrok.io URL"
echo ""
echo "  3. Register the webhook URL with GroupMe:"
echo "     → https://dev.groupme.com/bots → Edit your bot"
echo "     → Callback URL: https://your-tunnel-url/webhook?token=YOUR_TOKEN"
echo ""
echo "  4. Start the bot service:"
echo "     sudo systemctl start groupme-bot"
echo "     sudo systemctl status groupme-bot"
echo ""
echo "  5. Test it:"
echo "     Send !help in your GroupMe group"
echo ""
echo "  View logs:"
echo "     sudo journalctl -u groupme-bot -f"
echo "     tail -f ${INSTALL_DIR}/logs/groupme_bot.log"
echo ""
