"""
messenger.py — GroupMe Bot API client.

Encapsulates all outbound HTTP communication with the GroupMe Bot API.
The bot sends messages by POSTing to the v3/bots/post endpoint with its
BOT_ID.  There is no authentication header required for this endpoint —
the BOT_ID acts as the credential, which is why it must be kept secret
and stored in an environment variable rather than committed to source.

Retry logic
-----------
Network blips on a home connection or cellular failover are common on SBCs.
The client performs up to MAX_RETRIES attempts with an exponential backoff
so transient failures don't cause lost messages.
"""

import os
import time
from typing import Optional

import requests

from app.logger import get_logger

logger = get_logger(__name__)

# ------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------
GROUPME_BOT_POST_URL = "https://api.groupme.com/v3/bots/post"
GROUPME_MAX_MESSAGE_LENGTH = 1000   # GroupMe hard limit
BOT_MESSAGE_LIMIT = 900             # Our conservative limit (matches output trim)
REQUEST_TIMEOUT = 10                # Seconds to wait for GroupMe API response
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.5            # Seconds; multiplied by attempt number


def send_message(text: str, bot_id: Optional[str] = None) -> bool:
    """
    Send *text* to the GroupMe group via the Bot API.

    Args:
        text:   Message body.  Will be hard-truncated if somehow longer
                than BOT_MESSAGE_LIMIT (defence-in-depth).
        bot_id: GroupMe Bot ID.  If None, read from the ``BOT_ID``
                environment variable.

    Returns:
        True if the message was accepted by GroupMe, False otherwise.
    """
    resolved_bot_id = bot_id or os.environ.get("BOT_ID", "")
    if not resolved_bot_id:
        logger.error(
            "BOT_ID is not set — cannot send message.  "
            "Set the BOT_ID environment variable."
        )
        return False

    # Hard truncation as a last-resort safety net
    if len(text) > BOT_MESSAGE_LIMIT:
        logger.warning(
            "Message length %d exceeds limit %d — truncating.",
            len(text),
            BOT_MESSAGE_LIMIT,
        )
        text = text[: BOT_MESSAGE_LIMIT - 3] + "..."

    payload = {
        "bot_id": resolved_bot_id,
        "text": text,
    }

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.post(
                GROUPME_BOT_POST_URL,
                json=payload,
                timeout=REQUEST_TIMEOUT,
            )
            # GroupMe returns 202 Accepted on success
            if response.status_code == 202:
                logger.info(
                    "Message sent successfully (attempt %d/%d). "
                    "Length: %d chars.",
                    attempt,
                    MAX_RETRIES,
                    len(text),
                )
                return True

            # Non-202 is treated as a transient error unless it's a 4xx
            # (which indicates a permanent client error such as bad BOT_ID)
            if 400 <= response.status_code < 500:
                logger.error(
                    "GroupMe API returned client error %d — will not retry.  "
                    "Check your BOT_ID.  Response: %s",
                    response.status_code,
                    response.text[:200],
                )
                return False

            logger.warning(
                "GroupMe API returned %d on attempt %d/%d.  Retrying…",
                response.status_code,
                attempt,
                MAX_RETRIES,
            )

        except requests.exceptions.Timeout:
            logger.warning(
                "Request to GroupMe timed out on attempt %d/%d.",
                attempt,
                MAX_RETRIES,
            )
        except requests.exceptions.ConnectionError as exc:
            logger.warning(
                "Connection error on attempt %d/%d: %s",
                attempt,
                MAX_RETRIES,
                exc,
            )
        except requests.exceptions.RequestException as exc:
            logger.error("Unrecoverable request error: %s", exc)
            return False

        # Exponential backoff before next retry
        if attempt < MAX_RETRIES:
            sleep_time = RETRY_BACKOFF_BASE * attempt
            logger.debug("Sleeping %.1fs before retry…", sleep_time)
            time.sleep(sleep_time)

    logger.error("Failed to send message after %d attempts.", MAX_RETRIES)
    return False
