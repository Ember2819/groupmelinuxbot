"""
main.py — Flask webhook endpoint for the GroupMe bot.

Webhook flow
============
1.  GroupMe POSTs a JSON payload to /webhook whenever a message is sent
    in the group.
2.  We verify the payload has the expected structure.
3.  We skip messages sent by bots (including ourselves) to prevent loops.
4.  We extract the first token from the message text and look it up in the
    command whitelist.
5.  We apply rate limiting.
6.  We execute the command and post the result back to GroupMe.

Token verification
==================
GroupMe does not currently provide a webhook signature verification
mechanism (unlike Slack or GitHub), so we rely on:
  - The endpoint being served only over HTTPS (via Cloudflare Tunnel or ngrok)
  - An optional WEBHOOK_TOKEN query-parameter check as a basic secret
  - The BOT_ID being the only credential needed to send messages

The optional WEBHOOK_TOKEN check is a defence-in-depth measure: even if
someone discovers our webhook URL, they cannot trigger commands without
knowing the token.

Running in production
=====================
Use a proper WSGI server (gunicorn) rather than Flask's built-in dev
server.  The systemd service file handles this.
"""

import hashlib
import hmac
import os

from flask import Flask, abort, jsonify, request

from app.commands import execute_command
from app.logger import get_logger
from app.messenger import send_message
from app.rate_limiter import RateLimiter

# Import dotenv support — load .env before anything else reads os.environ
from dotenv import load_dotenv

load_dotenv()

logger = get_logger(__name__)

# ------------------------------------------------------------------
# App factory
# ------------------------------------------------------------------
app = Flask(__name__)

# Shared rate limiter instance (module-level singleton)
_rate_limiter = RateLimiter()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _is_bot_message(data: dict) -> bool:
    """
    Return True if the message was sent by a bot.

    GroupMe sets ``sender_type`` to ``"bot"`` for bot-originated messages.
    Checking this prevents infinite loops where our own reply triggers a
    new webhook call that triggers another command execution.
    """
    return data.get("sender_type", "").lower() == "bot"


def _verify_token(req) -> bool:
    """
    Optional WEBHOOK_TOKEN check.

    If the WEBHOOK_TOKEN environment variable is set, the incoming request
    MUST include ?token=<value> matching it.  If the variable is not set,
    this check is skipped (to ease initial setup).
    """
    expected = os.environ.get("WEBHOOK_TOKEN", "")
    if not expected:
        return True   # Token checking disabled
    provided = req.args.get("token", "")
    # Constant-time comparison prevents timing attacks
    return hmac.compare_digest(
        hashlib.sha256(provided.encode()).digest(),
        hashlib.sha256(expected.encode()).digest(),
    )


def _extract_command(text: str) -> str | None:
    """
    Extract the first whitespace-delimited token from *text*.

    Returns the token in lowercase if it starts with '!', otherwise None.
    We intentionally do NOT use shlex.split here for the purpose of
    *executing* anything — we only need the first token.
    """
    if not text:
        return None
    token = text.strip().split()[0].lower()
    return token if token.startswith("!") else None


# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------

@app.route("/webhook", methods=["POST"])
def webhook():
    """
    Main webhook endpoint.

    GroupMe sends a POST with a JSON body.  We process it and always return
    a 200 OK quickly so GroupMe doesn't retry.  Heavy lifting (command
    execution, outbound HTTP to GroupMe) is done synchronously here because
    on a Le Potato the total latency is still well under GroupMe's timeout.

    For very high-throughput groups, consider moving execution to a
    background thread or task queue.
    """
    # --- Token verification ---
    if not _verify_token(request):
        logger.warning(
            "Request rejected: invalid or missing token.  "
            "IP: %s", request.remote_addr
        )
        abort(403)

    # --- Parse body ---
    data = request.get_json(silent=True)
    if not data:
        logger.warning("Received non-JSON body from %s", request.remote_addr)
        abort(400)

    logger.debug("Webhook payload received: %s", data)

    # --- Ignore bot messages (anti-loop guard) ---
    if _is_bot_message(data):
        logger.debug("Ignoring bot-originated message from sender_id=%s", data.get("sender_id"))
        return jsonify({"status": "ignored", "reason": "bot_message"}), 200

    # --- Extract message text ---
    text: str = data.get("text", "").strip()
    sender_name: str = data.get("name", "unknown")
    sender_id: str = data.get("sender_id", "unknown")

    if not text:
        return jsonify({"status": "ignored", "reason": "empty_text"}), 200

    logger.info(
        "Message received from '%s' (id=%s): %r",
        sender_name, sender_id, text[:100],
    )

    # --- Check if it looks like a command ---
    command = _extract_command(text)
    if command is None:
        # Not a command — silently ignore
        return jsonify({"status": "ignored", "reason": "not_a_command"}), 200

    # --- Rate limiting ---
    allowed, reason = _rate_limiter.is_allowed()
    if not allowed:
        logger.info("Command '%s' rate-limited: %s", command, reason)
        send_message(f"⏳ Rate limited: {reason}")
        return jsonify({"status": "rate_limited"}), 200

    # --- Execute command (whitelist lookup happens inside execute_command) ---
    logger.info(
        "Dispatching command '%s' for user '%s'",
        command, sender_name,
    )
    output = execute_command(command)

    if output is None:
        # Command not in whitelist
        logger.info("Unknown command '%s' from '%s'", command, sender_name)
        send_message(
            f"❓ Unknown command: {command}\n"
            "Type !help to see available commands."
        )
        return jsonify({"status": "unknown_command"}), 200

    # --- Send result back to GroupMe ---
    header = f"[{command}]\n"
    full_message = header + output

    success = send_message(full_message)
    if success:
        logger.info("Response sent for command '%s'.", command)
    else:
        logger.error("Failed to send response for command '%s'.", command)

    return jsonify({"status": "ok"}), 200


@app.route("/health", methods=["GET"])
def health():
    """
    Simple health-check endpoint.

    Returns 200 with a JSON body.  Used by systemd's
    ``ExecStartPost`` or an external monitor to verify the service is alive.
    """
    return jsonify({"status": "healthy", "service": "groupme-bot"}), 200


@app.route("/", methods=["GET"])
def index():
    """Minimal root endpoint — confirms the service is reachable."""
    return jsonify({
        "service": "GroupMe Bot",
        "status": "running",
        "endpoints": ["/webhook (POST)", "/health (GET)"],
    }), 200


# ------------------------------------------------------------------
# Entry point (development only — use gunicorn in production)
# ------------------------------------------------------------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "false").lower() == "true"

    logger.info(
        "Starting Flask development server on port %d (debug=%s).  "
        "Use gunicorn in production.",
        port, debug,
    )
    app.run(host="0.0.0.0", port=port, debug=debug)
