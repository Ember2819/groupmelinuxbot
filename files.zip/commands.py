"""
commands.py — Whitelist-based command handler.

SECURITY MODEL
==============
Every command that the bot will ever execute is listed here as a hard-coded
mapping from chat trigger to a *frozen* argv list.  The mapping is evaluated
at module import time — nothing is built from user input.

Why shell=False?
    subprocess.run(..., shell=True) passes the command through /bin/sh, which
    means any shell metacharacter embedded in the command string can be
    interpreted — a classic injection vector.  With shell=False the kernel
    exec()s the binary directly; the shell is never involved.

Why shlex.split for display only (not for execution)?
    shlex.split is used when logging or echoing the command string.  The
    actual argv used for Popen is a pre-validated list literal, so there is
    literally no user-controlled string that gets split and executed.

Why a frozenset whitelist?
    Freezing the command-to-argv mapping at import time means no runtime code
    path can add new entries.  A dict would allow `COMMANDS[key] = ...` by
    accident; a module-level constant dict is nearly as good, but the
    convention of treating it as immutable (and the frozenset of valid keys)
    makes the intent explicit.
"""

import subprocess
import time
from typing import Optional

from app.logger import get_logger

logger = get_logger(__name__)

# ------------------------------------------------------------------
# Output limits
# ------------------------------------------------------------------
MAX_OUTPUT_CHARS: int = 900   # GroupMe messages cap at ~1000 chars
COMMAND_TIMEOUT: int = 15     # Seconds before subprocess is killed

# ------------------------------------------------------------------
# Whitelist — the ONLY commands the bot will ever run.
#
# Key   : exactly what the user types in GroupMe (lowercase, leading !)
# Value : argv list passed directly to subprocess.run (shell=False)
#
# Rules for adding entries:
#   - Never include rm, dd, mkfs, passwd, visudo, or any destructive command.
#   - Never use shell features (pipes, redirects, &&, etc.).  If you need
#     pipeline-style output (e.g. grep inside ps), capture stdout in Python
#     and post-process it — see the helpers below.
#   - Prefer absolute paths (/usr/bin/...) to resist PATH manipulation.
# ------------------------------------------------------------------
COMMANDS: dict[str, list[str]] = {
    # --- System info ---
    "!uptime":       ["/usr/bin/uptime"],
    "!whoami":       ["/usr/bin/whoami"],
    "!hostname":     ["/bin/hostname"],
    "!ip":           ["/bin/hostname", "-I"],
    "!kernel":       ["/bin/uname", "-r"],
    "!date":         ["/bin/date"],
    "!arch":         ["/bin/uname", "-m"],
    "!os":           ["/bin/cat", "/etc/os-release"],
    "!cpuinfo":      ["/bin/cat", "/proc/cpuinfo"],
    "!loadavg":      ["/bin/cat", "/proc/loadavg"],
    "!uptime_raw":   ["/bin/cat", "/proc/uptime"],

    # --- Disk & filesystem ---
    "!disk":         ["/bin/df", "-h"],
    "!disk_root":    ["/bin/df", "-h", "/"],
    "!lsblk":        ["/bin/lsblk"],
    "!mount":        ["/bin/mount"],
    "!inode":        ["/bin/df", "-i"],

    # --- Memory ---
    "!memory":       ["/usr/bin/free", "-h"],
    "!memory_raw":   ["/usr/bin/free", "-b"],
    "!meminfo":      ["/bin/cat", "/proc/meminfo"],

    # --- CPU (no shell pipe — handled in Python below) ---
    "!cpu":          "__cpu__",   # Special: post-processed in Python
    "!cpu_full":     ["/usr/bin/top", "-bn1"],

    # --- Processes ---
    "!processes":    "__processes__",    # Special: sorted + truncated in Python
    "!pstree":       ["/usr/bin/pstree", "-p"],
    "!threads":      ["/bin/ls", "/proc/self/task"],

    # --- Network ---
    "!ifconfig":     ["/sbin/ip", "addr"],
    "!route":        ["/sbin/ip", "route"],
    "!netstat":      ["/bin/ss", "-tuln"],
    "!ping_gw":      "__ping__",         # Special: single ping to gateway
    "!arp":          ["/sbin/arp", "-n"],
    "!dns":          ["/bin/cat", "/etc/resolv.conf"],
    "!hosts":        ["/bin/cat", "/etc/hosts"],
    "!nslookup":     ["/usr/bin/nslookup", "google.com"],

    # --- Services & systemd ---
    "!services":     [
        "/bin/systemctl", "list-units",
        "--type=service", "--state=running",
        "--no-pager", "--no-legend",
    ],
    "!failed":       [
        "/bin/systemctl", "list-units",
        "--state=failed", "--no-pager", "--no-legend",
    ],
    "!timers":       [
        "/bin/systemctl", "list-timers",
        "--no-pager", "--no-legend",
    ],

    # --- Logs (last N lines only — safe, no injection) ---
    "!syslog":       ["/usr/bin/tail", "-n", "10", "/var/log/syslog"],
    "!auth_log":     ["/usr/bin/tail", "-n", "10", "/var/log/auth.log"],
    "!dmesg":        "__dmesg__",        # Special: last 10 lines via Python

    # --- File listing (read-only, restricted paths) ---
    "!ls":           ["/bin/ls", "-lh", "--color=never", "/home"],
    "!ls_tmp":       ["/bin/ls", "-lh", "--color=never", "/tmp"],
    "!ls_var":       ["/bin/ls", "-lh", "--color=never", "/var/log"],

    # --- Hardware / SBC-specific ---
    "!temperature":  "__temperature__",  # Special: tries vcgencmd, falls back
    "!voltage":      "__voltage__",      # Special: vcgencmd measure_volts core

    # --- Git (read-only, operates on bot's own repo) ---
    "!git_status":   "__git_status__",   # Special: runs in bot's own directory
    "!git_log":      "__git_log__",      # Special: last 5 commits

    # --- Users & groups ---
    "!users":        ["/usr/bin/who"],
    "!last":         ["/usr/bin/last", "-n", "5"],
    "!groups":       ["/usr/bin/groups"],
    "!id":           ["/usr/bin/id"],

    # --- Packages ---
    "!pkg_count":    "__pkg_count__",    # Special: dpkg count
    "!apt_upgrades": "__apt_upgrades__", # Special: list upgradeable

    # --- Miscellaneous ---
    "!env":          "__env__",          # Special: safe subset of env vars
    "!crontab":      ["/usr/bin/crontab", "-l"],
    "!locale":       ["/usr/bin/locale"],
    "!timezone":     ["/bin/cat", "/etc/timezone"],
    "!help":         "__help__",         # Special: lists available commands
}

# Sentinel value used for "special" handlers
_SPECIAL = "__"

# Pre-computed set of valid command strings for O(1) lookup
VALID_COMMANDS: frozenset[str] = frozenset(COMMANDS.keys())

# ------------------------------------------------------------------
# Bot's own project directory (used for git commands)
# ------------------------------------------------------------------
import os
BOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ==================================================================
# Private helpers
# ==================================================================

def _run(argv: list[str], cwd: Optional[str] = None) -> str:
    """
    Execute *argv* with shell=False and return its stdout as a string.

    Errors (non-zero exit, timeout, file-not-found) are caught and returned
    as a human-readable error message so the bot always replies with
    *something* rather than crashing.
    """
    logger.debug("Executing: %s", " ".join(argv))
    try:
        result = subprocess.run(
            argv,
            shell=False,           # SECURITY: never pass through a shell
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT,
            cwd=cwd,
        )
        output = result.stdout
        if result.returncode != 0 and result.stderr:
            output += f"\n[stderr]: {result.stderr.strip()}"
        return output.strip()
    except FileNotFoundError:
        logger.warning("Binary not found: %s", argv[0])
        return f"[Error] Command not found: {argv[0]}"
    except subprocess.TimeoutExpired:
        logger.warning("Command timed out: %s", " ".join(argv))
        return f"[Error] Command timed out after {COMMAND_TIMEOUT}s"
    except PermissionError as exc:
        logger.warning("Permission denied: %s — %s", argv[0], exc)
        return f"[Error] Permission denied: {argv[0]}"
    except Exception as exc:  # pylint: disable=broad-except
        logger.exception("Unexpected error running %s", argv[0])
        return f"[Error] Unexpected error: {exc}"


def _trim(text: str) -> str:
    """
    Trim output to MAX_OUTPUT_CHARS.  If trimming occurs, append a notice
    so the GroupMe user knows they're seeing a truncated result.
    """
    if len(text) <= MAX_OUTPUT_CHARS:
        return text
    trimmed = text[:MAX_OUTPUT_CHARS]
    # Try not to cut mid-line
    last_newline = trimmed.rfind("\n")
    if last_newline > MAX_OUTPUT_CHARS // 2:
        trimmed = trimmed[:last_newline]
    return trimmed + f"\n… [output trimmed to {MAX_OUTPUT_CHARS} chars]"


# ------------------------------------------------------------------
# Special handlers — Python-level post-processing avoids shell pipes
# ------------------------------------------------------------------

def _handle_cpu() -> str:
    """Parse CPU usage out of `top -bn1` without a shell pipe."""
    raw = _run(["/usr/bin/top", "-bn1"])
    for line in raw.splitlines():
        if "Cpu(s)" in line or "cpu" in line.lower():
            return line.strip()
    return "Could not parse CPU info from top output."


def _handle_processes() -> str:
    """Return top-5 memory-consuming processes.  Sorts in Python."""
    raw = _run(["/bin/ps", "aux"])
    lines = raw.splitlines()
    if not lines:
        return "No process data."
    header = lines[0]
    # Column 3 = CPU%, column 4 = MEM% in ps aux output
    try:
        data_lines = sorted(lines[1:], key=lambda l: float(l.split()[3]), reverse=True)
    except (IndexError, ValueError):
        data_lines = lines[1:]
    top5 = [header] + data_lines[:5]
    return "\n".join(top5)


def _handle_dmesg() -> str:
    """Return last 10 kernel ring-buffer lines."""
    raw = _run(["/bin/dmesg", "--time-format=reltime"])
    lines = raw.splitlines()
    return "\n".join(lines[-10:]) if lines else "No dmesg output."


def _handle_temperature() -> str:
    """
    Try vcgencmd (Raspberry Pi / Le Potato), fall back to reading the
    thermal zone sysfs file which is present on most Linux SBCs.
    """
    # vcgencmd path on most ARM SBCs
    vcgencmd = "/usr/bin/vcgencmd"
    if os.path.exists(vcgencmd):
        return _run([vcgencmd, "measure_temp"])

    # Generic sysfs fallback
    thermal_path = "/sys/class/thermal/thermal_zone0/temp"
    if os.path.exists(thermal_path):
        raw = _run(["/bin/cat", thermal_path])
        try:
            celsius = int(raw.strip()) / 1000
            return f"temp={celsius:.1f}'C"
        except ValueError:
            return f"Raw thermal reading: {raw}"

    return "Temperature sensor not available on this device."


def _handle_voltage() -> str:
    """Read core voltage via vcgencmd or report unavailable."""
    vcgencmd = "/usr/bin/vcgencmd"
    if os.path.exists(vcgencmd):
        return _run([vcgencmd, "measure_volts", "core"])
    return "vcgencmd not available on this device."


def _handle_ping() -> str:
    """Ping the default gateway once to check LAN connectivity."""
    # Find gateway from routing table
    route_raw = _run(["/sbin/ip", "route"])
    gateway = None
    for line in route_raw.splitlines():
        if line.startswith("default"):
            parts = line.split()
            if len(parts) >= 3:
                gateway = parts[2]
                break
    if not gateway:
        return "Could not determine default gateway."
    return _run(["/bin/ping", "-c", "1", "-W", "3", gateway])


def _handle_git_status() -> str:
    """Run git status in the bot's own project directory."""
    return _run(["/usr/bin/git", "status", "--short"], cwd=BOT_DIR)


def _handle_git_log() -> str:
    """Show last 5 commits from the bot's own repo."""
    return _run(
        ["/usr/bin/git", "log", "--oneline", "-5"],
        cwd=BOT_DIR,
    )


def _handle_pkg_count() -> str:
    """Count installed Debian packages without shell pipes."""
    raw = _run(["/usr/bin/dpkg", "--list"])
    count = sum(1 for l in raw.splitlines() if l.startswith("ii"))
    return f"Installed packages: {count}"


def _handle_apt_upgrades() -> str:
    """List packages with available upgrades (read-only, no sudo needed)."""
    return _run(["/usr/bin/apt", "list", "--upgradeable"])


def _handle_env() -> str:
    """
    Return a *safe* subset of environment variables.  Never expose secrets,
    tokens, or passwords that may be present in the process environment.
    """
    safe_keys = {
        "HOME", "USER", "SHELL", "LANG", "LC_ALL", "TZ",
        "PATH", "PWD", "VIRTUAL_ENV", "PYTHONPATH",
    }
    lines = []
    for k, v in sorted(os.environ.items()):
        if k in safe_keys:
            lines.append(f"{k}={v}")
    return "\n".join(lines) if lines else "(no safe env vars found)"


def _handle_help() -> str:
    """Return a sorted list of all available commands."""
    cmds = sorted(VALID_COMMANDS)
    # Split into rows of 4 for compact display
    rows = []
    row: list[str] = []
    for cmd in cmds:
        row.append(cmd)
        if len(row) == 4:
            rows.append("  ".join(f"{c:<14}" for c in row))
            row = []
    if row:
        rows.append("  ".join(f"{c:<14}" for c in row))
    return "Available commands:\n" + "\n".join(rows)


# Dispatch table for special handlers
_SPECIAL_DISPATCH: dict[str, callable] = {
    "__cpu__":          _handle_cpu,
    "__processes__":    _handle_processes,
    "__dmesg__":        _handle_dmesg,
    "__temperature__":  _handle_temperature,
    "__voltage__":      _handle_voltage,
    "__ping__":         _handle_ping,
    "__git_status__":   _handle_git_status,
    "__git_log__":      _handle_git_log,
    "__pkg_count__":    _handle_pkg_count,
    "__apt_upgrades__": _handle_apt_upgrades,
    "__env__":          _handle_env,
    "__help__":         _handle_help,
}


# ==================================================================
# Public API
# ==================================================================

def execute_command(trigger: str) -> Optional[str]:
    """
    Execute the whitelisted command mapped to *trigger* and return the
    trimmed output, or ``None`` if the trigger is not in the whitelist.

    Args:
        trigger: The raw command token from the GroupMe message
                 (e.g. ``"!disk"``).

    Returns:
        Output string (≤ MAX_OUTPUT_CHARS) or None if unknown command.
    """
    trigger = trigger.strip().lower()

    if trigger not in VALID_COMMANDS:
        logger.info("Unknown command rejected: %r", trigger)
        return None

    argv_or_sentinel = COMMANDS[trigger]

    # ------ Special handler path ------
    if isinstance(argv_or_sentinel, str) and argv_or_sentinel.startswith("__"):
        handler = _SPECIAL_DISPATCH.get(argv_or_sentinel)
        if handler is None:
            logger.error("No handler for sentinel %r", argv_or_sentinel)
            return "[Error] Internal configuration error."
        logger.info("Running special handler for %s", trigger)
        start = time.monotonic()
        output = handler()
        elapsed = time.monotonic() - start
        logger.debug("Handler for %s completed in %.2fs", trigger, elapsed)
        return _trim(output)

    # ------ Normal argv path ------
    logger.info("Running command for trigger %s: %s", trigger, " ".join(argv_or_sentinel))
    start = time.monotonic()
    output = _run(argv_or_sentinel)
    elapsed = time.monotonic() - start
    logger.debug("Command for %s completed in %.2fs", trigger, elapsed)
    return _trim(output)
